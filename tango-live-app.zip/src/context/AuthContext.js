import React, { createContext, useState, useEffect, useContext } from 'react';
import { auth, firestore } from '../services/firebase';
import { GoogleSignin } from '@react-native-google-signin/google-signin';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    // ⚠️ استبدل هذا بـ Web Client ID من Firebase → Authentication → Google
    GoogleSignin.configure({
      webClientId: '774056839517-xxxxxxxxxxxxxxxx.apps.googleusercontent.com',
    });

    const unsubscribe = auth().onAuthStateChanged(async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        const doc = await firestore().collection('users').doc(firebaseUser.uid).get();
        if (doc.exists) {
          setUserData(doc.data());
        } else {
          const newUser = {
            uid: firebaseUser.uid,
            displayName: firebaseUser.displayName || 'User',
            email: firebaseUser.email,
            photoURL: firebaseUser.photoURL || '',
            coins: 1000,
            followers: 0,
            following: 0,
            createdAt: firestore.FieldValue.serverTimestamp(),
          };
          await firestore().collection('users').doc(firebaseUser.uid).set(newUser);
          setUserData(newUser);
        }
      } else {
        setUser(null);
        setUserData(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signInWithGoogle = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const { idToken } = await GoogleSignin.signIn();
      const googleCredential = auth.GoogleAuthProvider.credential(idToken);
      return auth().signInWithCredential(googleCredential);
    } catch (error) {
      console.error(error);
      throw error;
    }
  };

  const signInAnonymously = async () => {
    return auth().signInAnonymously();
  };

  const signOut = async () => {
    await GoogleSignin.signOut();
    return auth().signOut();
  };

  const updateCoins = async (amount) => {
    if (!user) return;
    const newCoins = (userData?.coins || 0) + amount;
    await firestore().collection('users').doc(user.uid).update({ coins: newCoins });
    setUserData({ ...userData, coins: newCoins });
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      userData, 
      loading, 
      signInWithGoogle, 
      signInAnonymously, 
      signOut,
      updateCoins 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
