import React, { useState, useEffect, useRef } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, TextInput, 
  PermissionsAndroid, Platform, StatusBar 
} from 'react-native';
import { RtcSurfaceView, VideoRenderMode, ClientRole } from 'react-native-agora';
import { useAuth } from '../context/AuthContext';
import { firestore } from '../services/firebase';
import AgoraService from '../services/agora';
import Icon from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

export default function GoLiveScreen() {
  const { user, userData } = useAuth();
  const navigation = useNavigation();
  const [title, setTitle] = useState('');
  const [isLive, setIsLive] = useState(false);
  const [joined, setJoined] = useState(false);
  const [mutedAudio, setMutedAudio] = useState(false);
  const [mutedVideo, setMutedVideo] = useState(false);
  const [viewers, setViewers] = useState(0);
  const channelName = useRef(`stream_${user?.uid}_${Date.now()}`);
  const streamId = useRef(null);

  useEffect(() => {
    requestPermissions();
    return () => {
      if (isLive) endStream();
    };
  }, []);

  const requestPermissions = async () => {
    if (Platform.OS === 'android') {
      await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.CAMERA,
        PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
      ]);
    }
  };

  const startStream = async () => {
    if (!title.trim()) return;

    try {
      await AgoraService.initialize();

      // Create stream document in Firestore
      const streamDoc = await firestore().collection('streams').add({
        hostId: user.uid,
        hostName: userData?.displayName || 'User',
        hostPhoto: userData?.photoURL || '',
        title: title,
        channelName: channelName.current,
        isLive: true,
        viewers: 0,
        startedAt: firestore.FieldValue.serverTimestamp(),
      });

      streamId.current = streamDoc.id;

      // Join Agora channel as broadcaster
      await AgoraService.joinChannel(null, channelName.current, parseInt(user.uid), ClientRole.Broadcaster);

      setIsLive(true);
      setJoined(true);

      // Listen to viewer count
      const unsub = firestore().collection('streams').doc(streamDoc.id)
        .onSnapshot(doc => {
          if (doc.exists) setViewers(doc.data().viewers || 0);
        });

    } catch (error) {
      console.error('Start stream error:', error);
    }
  };

  const endStream = async () => {
    try {
      await AgoraService.leaveChannel();
      AgoraService.destroy();

      if (streamId.current) {
        await firestore().collection('streams').doc(streamId.current).update({
          isLive: false,
          endedAt: firestore.FieldValue.serverTimestamp(),
        });
      }

      setIsLive(false);
      setJoined(false);
      navigation.navigate('Discover');
    } catch (error) {
      console.error('End stream error:', error);
    }
  };

  const toggleAudio = async () => {
    await AgoraService.toggleMuteAudio(!mutedAudio);
    setMutedAudio(!mutedAudio);
  };

  const toggleVideo = async () => {
    await AgoraService.toggleMuteVideo(!mutedVideo);
    setMutedVideo(!mutedVideo);
  };

  const switchCamera = async () => {
    await AgoraService.switchCamera();
  };

  if (!isLive) {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />
        <Text style={styles.header}>🎥 ابدأ بثك المباشر</Text>
        <TextInput
          style={styles.input}
          placeholder="عنوان البث..."
          placeholderTextColor="#888"
          value={title}
          onChangeText={setTitle}
          maxLength={50}
        />
        <TouchableOpacity style={styles.startButton} onPress={startStream}>
          <Text style={styles.startText}>🔴 ابدأ البث الآن</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.liveContainer}>
      <StatusBar barStyle="light-content" />

      {joined && (
        <RtcSurfaceView
          style={styles.videoView}
          canvas={{ uid: parseInt(user.uid), renderMode: VideoRenderMode.Hidden }}
        />
      )}

      <View style={styles.overlay}>
        <View style={styles.topBar}>
          <View style={styles.liveIndicator}>
            <Text style={styles.liveText}>● LIVE</Text>
          </View>
          <View style={styles.viewersBox}>
            <Icon name="eye" size={16} color="#fff" />
            <Text style={styles.viewersText}>{viewers}</Text>
          </View>
        </View>

        <View style={styles.controls}>
          <TouchableOpacity style={styles.controlBtn} onPress={toggleAudio}>
            <Icon name={mutedAudio ? "mic-off" : "mic"} size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.controlBtn} onPress={toggleVideo}>
            <Icon name={mutedVideo ? "videocam-off" : "videocam"} size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.controlBtn} onPress={switchCamera}>
            <Icon name="camera-reverse" size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.controlBtn, styles.endBtn]} onPress={endStream}>
            <Icon name="close" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f1e', justifyContent: 'center', alignItems: 'center', padding: 20 },
  header: { fontSize: 28, fontWeight: 'bold', color: '#fff', marginBottom: 30 },
  input: {
    width: '100%', maxWidth: 350, backgroundColor: '#1a1a2e', color: '#fff',
    paddingHorizontal: 20, paddingVertical: 16, borderRadius: 12,
    fontSize: 16, marginBottom: 20, borderWidth: 1, borderColor: '#2a2a4a'
  },
  startButton: {
    backgroundColor: '#FF2D55', paddingVertical: 18, paddingHorizontal: 40,
    borderRadius: 30, shadowColor: '#FF2D55', shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5, shadowRadius: 20, elevation: 15
  },
  startText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  liveContainer: { flex: 1, backgroundColor: '#000' },
  videoView: { flex: 1 },
  overlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'space-between', padding: 20 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 40 },
  liveIndicator: { backgroundColor: '#FF2D55', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 },
  liveText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  viewersBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16 },
  viewersText: { color: '#fff', marginLeft: 6, fontWeight: 'bold' },
  controls: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 30 },
  controlBtn: { width: 50, height: 50, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center', marginHorizontal: 10 },
  endBtn: { backgroundColor: '#FF2D55' }
});
