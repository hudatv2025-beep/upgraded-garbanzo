import React, { useEffect, useState, useRef } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, TextInput, 
  FlatList, KeyboardAvoidingView, Platform, StatusBar, Animated 
} from 'react-native';
import { RtcSurfaceView, VideoRenderMode, ClientRole } from 'react-native-agora';
import { useRoute, useNavigation } from '@react-navigation/native';
import { firestore } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import AgoraService from '../services/agora';
import Icon from 'react-native-vector-icons/Ionicons';

const GIFTS = [
  { id: 'rose', name: '🌹 وردة', cost: 10 },
  { id: 'heart', name: '❤️ قلب', cost: 50 },
  { id: 'crown', name: '👑 تاج', cost: 100 },
  { id: 'diamond', name: '💎 ألماس', cost: 500 },
  { id: 'rocket', name: '🚀 صاروخ', cost: 1000 },
];

export default function LiveScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { user, userData, updateCoins } = useAuth();
  const { streamId, channelName } = route.params;

  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [joined, setJoined] = useState(false);
  const [streamInfo, setStreamInfo] = useState(null);
  const [showGifts, setShowGifts] = useState(false);
  const [giftAnimation, setGiftAnimation] = useState(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    joinStream();

    const streamUnsub = firestore().collection('streams').doc(streamId)
      .onSnapshot(doc => {
        if (doc.exists) {
          const data = doc.data();
          setStreamInfo(data);
          if (!data.isLive) {
            navigation.goBack();
          }
        }
      });

    const msgUnsub = firestore()
      .collection('streams').doc(streamId).collection('messages')
      .orderBy('timestamp', 'desc')
      .limit(50)
      .onSnapshot(snapshot => {
        const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setMessages(msgs.reverse());
      });

    const giftsUnsub = firestore()
      .collection('streams').doc(streamId).collection('gifts')
      .orderBy('timestamp', 'desc')
      .limit(1)
      .onSnapshot(snapshot => {
        snapshot.docChanges().forEach(change => {
          if (change.type === 'added') {
            showGiftAnimation(change.doc.data());
          }
        });
      });

    // Increment viewers
    const viewerRef = firestore().collection('streams').doc(streamId);
    viewerRef.update({ viewers: firestore.FieldValue.increment(1) });

    return () => {
      streamUnsub();
      msgUnsub();
      giftsUnsub();
      leaveStream();
      viewerRef.update({ viewers: firestore.FieldValue.increment(-1) });
    };
  }, []);

  const joinStream = async () => {
    try {
      await AgoraService.initialize();
      await AgoraService.joinChannel(null, channelName, parseInt(user.uid) + 999999, ClientRole.Audience);
      setJoined(true);
    } catch (error) {
      console.error('Join error:', error);
    }
  };

  const leaveStream = async () => {
    await AgoraService.leaveChannel();
    AgoraService.destroy();
    setJoined(false);
  };

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    await firestore()
      .collection('streams').doc(streamId).collection('messages')
      .add({
        text: newMessage,
        senderId: user.uid,
        senderName: userData?.displayName || 'Guest',
        senderPhoto: userData?.photoURL || '',
        timestamp: firestore.FieldValue.serverTimestamp(),
      });

    setNewMessage('');
  };

  const sendGift = async (gift) => {
    if ((userData?.coins || 0) < gift.cost) {
      alert('رصيدك غير كافٍ!');
      return;
    }

    await updateCoins(-gift.cost);

    await firestore()
      .collection('streams').doc(streamId).collection('gifts')
      .add({
        giftId: gift.id,
        giftName: gift.name,
        senderId: user.uid,
        senderName: userData?.displayName || 'Guest',
        cost: gift.cost,
        timestamp: firestore.FieldValue.serverTimestamp(),
      });

    // Add coins to host
    if (streamInfo?.hostId) {
      await firestore().collection('users').doc(streamInfo.hostId)
        .update({ coins: firestore.FieldValue.increment(gift.cost) });
    }

    setShowGifts(false);
  };

  const showGiftAnimation = (giftData) => {
    setGiftAnimation(giftData);
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.delay(2000),
      Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => setGiftAnimation(null));
  };

  const renderMessage = ({ item }) => (
    <View style={styles.messageRow}>
      <Text style={styles.messageName}>{item.senderName}:</Text>
      <Text style={styles.messageText}>{item.text}</Text>
    </View>
  );

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" />

      {/* Video */}
      <View style={styles.videoContainer}>
        {joined && (
          <RtcSurfaceView
            style={styles.video}
            canvas={{ uid: parseInt(streamInfo?.hostId || 0), renderMode: VideoRenderMode.Hidden }}
          />
        )}
      </View>

      {/* Overlay */}
      <View style={styles.overlay} pointerEvents="box-none">
        {/* Top Bar */}
        <View style={styles.topBar} pointerEvents="auto">
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Icon name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.hostInfo}>
            <Text style={styles.hostName}>{streamInfo?.hostName}</Text>
            <View style={styles.viewersBox}>
              <Icon name="eye" size={14} color="#fff" />
              <Text style={styles.viewersText}>{streamInfo?.viewers || 0}</Text>
            </View>
          </View>
        </View>

        {/* Gift Animation */}
        {giftAnimation && (
          <Animated.View style={[styles.giftAnimContainer, { opacity: fadeAnim }]}>
            <Text style={styles.giftAnimText}>
              {giftAnimation.senderName} أرسل {giftAnimation.giftName}!
            </Text>
          </Animated.View>
        )}

        {/* Chat */}
        <View style={styles.chatContainer} pointerEvents="auto">
          <FlatList
            data={messages}
            renderItem={renderMessage}
            keyExtractor={item => item.id}
            style={styles.chatList}
            showsVerticalScrollIndicator={false}
          />
        </View>

        {/* Input & Gifts */}
        <View style={styles.bottomBar} pointerEvents="auto">
          {showGifts ? (
            <View style={styles.giftPanel}>
              <FlatList
                horizontal
                data={GIFTS}
                renderItem={({ item }) => (
                  <TouchableOpacity style={styles.giftItem} onPress={() => sendGift(item)}>
                    <Text style={styles.giftEmoji}>{item.name.split(' ')[0]}</Text>
                    <Text style={styles.giftName}>{item.name.split(' ')[1]}</Text>
                    <Text style={styles.giftCost}>{item.cost} 💰</Text>
                  </TouchableOpacity>
                )}
                keyExtractor={item => item.id}
                showsHorizontalScrollIndicator={false}
              />
              <TouchableOpacity onPress={() => setShowGifts(false)}>
                <Text style={styles.closeGifts}>✕ إغلاق</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder="اكتب رسالة..."
                placeholderTextColor="#888"
                value={newMessage}
                onChangeText={setNewMessage}
                onSubmitEditing={sendMessage}
              />
              <TouchableOpacity style={styles.giftBtn} onPress={() => setShowGifts(true)}>
                <Text style={styles.giftBtnText}>🎁</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
                <Icon name="send" size={20} color="#fff" />
              </TouchableOpacity>
            </View>
          )}
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  videoContainer: { flex: 1 },
  video: { flex: 1 },
  overlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'space-between' },
  topBar: { flexDirection: 'row', alignItems: 'center', paddingTop: 50, paddingHorizontal: 15 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  hostInfo: { marginLeft: 12 },
  hostName: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  viewersBox: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  viewersText: { color: '#fff', marginLeft: 4, fontSize: 12 },
  giftAnimContainer: { 
    position: 'absolute', top: '40%', alignSelf: 'center',
    backgroundColor: 'rgba(255,45,85,0.9)', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 20 
  },
  giftAnimText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  chatContainer: { maxHeight: 200, marginHorizontal: 10, marginBottom: 10 },
  chatList: { flexGrow: 0 },
  messageRow: { flexDirection: 'row', marginBottom: 4, backgroundColor: 'rgba(0,0,0,0.4)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, alignSelf: 'flex-start' },
  messageName: { color: '#FF2D55', fontWeight: 'bold', marginRight: 6 },
  messageText: { color: '#fff', fontSize: 14 },
  bottomBar: { paddingHorizontal: 10, paddingBottom: 20 },
  inputRow: { flexDirection: 'row', alignItems: 'center' },
  input: { 
    flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', color: '#fff',
    paddingHorizontal: 16, paddingVertical: 12, borderRadius: 25, fontSize: 14 
  },
  giftBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#FFD700', justifyContent: 'center', alignItems: 'center', marginHorizontal: 8 },
  giftBtnText: { fontSize: 22 },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#FF2D55', justifyContent: 'center', alignItems: 'center' },
  giftPanel: { backgroundColor: 'rgba(0,0,0,0.85)', padding: 15, borderRadius: 16 },
  giftItem: { alignItems: 'center', marginHorizontal: 12, padding: 10 },
  giftEmoji: { fontSize: 32 },
  giftName: { color: '#fff', fontSize: 12, marginTop: 4 },
  giftCost: { color: '#FFD700', fontSize: 12, marginTop: 2 },
  closeGifts: { color: '#FF2D55', textAlign: 'center', marginTop: 10, fontWeight: 'bold' }
});
