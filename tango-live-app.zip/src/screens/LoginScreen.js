import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen() {
  const { signInWithGoogle, signInAnonymously } = useAuth();

  return (
    <LinearGradient colors={['#1a1a2e', '#16213e', '#0f3460']} style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.logoContainer}>
        <View style={styles.logoCircle}>
          <Text style={styles.logoText}>🔴</Text>
        </View>
        <Text style={styles.title}>Tango Live</Text>
        <Text style={styles.subtitle}>بث مباشر. تواصل. استمتع.</Text>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.googleButton} onPress={signInWithGoogle}>
          <Text style={styles.googleButtonText}>🔵 تسجيل الدخول بـ Google</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.guestButton} onPress={signInAnonymously}>
          <Text style={styles.guestButtonText}>👤 دخول كضيف</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.terms}>
        بالدخول أنت توافق على شروط الاستخدام وسياسة الخصوصية
      </Text>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  logoContainer: { alignItems: 'center', marginBottom: 60 },
  logoCircle: { 
    width: 100, height: 100, borderRadius: 50, 
    backgroundColor: '#FF2D55', justifyContent: 'center', alignItems: 'center',
    shadowColor: '#FF2D55', shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8, shadowRadius: 20, elevation: 20 
  },
  logoText: { fontSize: 50 },
  title: { fontSize: 42, fontWeight: 'bold', color: '#fff', marginTop: 20 },
  subtitle: { fontSize: 16, color: '#aaa', marginTop: 10 },
  buttonContainer: { width: '100%', maxWidth: 350 },
  googleButton: {
    backgroundColor: '#fff', paddingVertical: 16, borderRadius: 30,
    alignItems: 'center', marginBottom: 15,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 10, elevation: 10
  },
  googleButtonText: { color: '#333', fontSize: 16, fontWeight: 'bold' },
  guestButton: {
    backgroundColor: 'transparent', paddingVertical: 16, borderRadius: 30,
    alignItems: 'center', borderWidth: 2, borderColor: '#FF2D55'
  },
  guestButtonText: { color: '#FF2D55', fontSize: 16, fontWeight: 'bold' },
  terms: { color: '#888', fontSize: 12, textAlign: 'center', marginTop: 30, maxWidth: 300 }
});
