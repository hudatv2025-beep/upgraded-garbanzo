import React, { useEffect, useState } from 'react';
import { 
  View, Text, StyleSheet, FlatList, TouchableOpacity, 
  Image, RefreshControl, StatusBar 
} from 'react-native';
import { firestore } from '../services/firebase';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

export default function HomeScreen() {
  const [streams, setStreams] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    fetchStreams();
    const unsubscribe = firestore()
      .collection('streams')
      .where('isLive', '==', true)
      .onSnapshot(snapshot => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setStreams(data);
      });
    return unsubscribe;
  }, []);

  const fetchStreams = async () => {
    setRefreshing(true);
    const snapshot = await firestore()
      .collection('streams')
      .where('isLive', '==', true)
      .orderBy('startedAt', 'desc')
      .get();
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setStreams(data);
    setRefreshing(false);
  };

  const renderStream = ({ item }) => (
    <TouchableOpacity 
      style={styles.streamCard}
      onPress={() => navigation.navigate('Live', { streamId: item.id, channelName: item.channelName })}
    >
      <View style={styles.thumbnail}>
        <View style={styles.liveBadge}>
          <Text style={styles.liveText}>● LIVE</Text>
        </View>
        <View style={styles.viewersBadge}>
          <Icon name="eye" size={14} color="#fff" />
          <Text style={styles.viewersText}>{item.viewers || 0}</Text>
        </View>
      </View>
      <View style={styles.info}>
        <Image source={{ uri: item.hostPhoto || 'https://via.placeholder.com/50' }} style={styles.avatar} />
        <View style={styles.textInfo}>
          <Text style={styles.hostName}>{item.hostName}</Text>
          <Text style={styles.title} numberOfLines={1}>{item.title}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🔴 البثوث المباشرة</Text>
      </View>
      <FlatList
        data={streams}
        renderItem={renderStream}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={fetchStreams} tintColor="#FF2D55" />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>لا يوجد بثوث مباشرة حالياً</Text>
            <Text style={styles.emptySub}>كن أول من يبدأ البث! 🎥</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f1e' },
  header: { paddingTop: 50, paddingHorizontal: 20, paddingBottom: 15, backgroundColor: '#1a1a2e' },
  headerTitle: { fontSize: 24, fontWeight: 'bold', color: '#fff' },
  list: { padding: 10 },
  streamCard: { 
    flex: 1, margin: 6, backgroundColor: '#1a1a2e', borderRadius: 16,
    overflow: 'hidden', elevation: 5 
  },
  thumbnail: { 
    height: 180, backgroundColor: '#2a2a4a', justifyContent: 'space-between', padding: 10 
  },
  liveBadge: { 
    backgroundColor: '#FF2D55', paddingHorizontal: 10, paddingVertical: 4, 
    borderRadius: 6, alignSelf: 'flex-start' 
  },
  liveText: { color: '#fff', fontWeight: 'bold', fontSize: 12 },
  viewersBadge: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-end', backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  viewersText: { color: '#fff', marginLeft: 4, fontSize: 12 },
  info: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  avatar: { width: 36, height: 36, borderRadius: 18, marginRight: 10 },
  textInfo: { flex: 1 },
  hostName: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  title: { color: '#aaa', fontSize: 12, marginTop: 2 },
  empty: { alignItems: 'center', marginTop: 100 },
  emptyText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  emptySub: { color: '#888', marginTop: 10 }
});
