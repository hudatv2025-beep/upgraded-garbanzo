import React, { useState, useEffect } from 'react';
import { 
  View, Text, StyleSheet, Image, TouchableOpacity, 
  FlatList, Alert 
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { firestore } from '../services/firebase';
import Icon from 'react-native-vector-icons/Ionicons';

export default function ProfileScreen() {
  const { user, userData, signOut } = useAuth();
  const [myStreams, setMyStreams] = useState([]);

  useEffect(() => {
    if (!user) return;
    const unsub = firestore()
      .collection('streams')
      .where('hostId', '==', user.uid)
      .orderBy('startedAt', 'desc')
      .limit(20)
      .onSnapshot(snapshot => {
        setMyStreams(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });
    return unsub;
  }, [user]);

  const handleSignOut = () => {
    Alert.alert('تسجيل الخروج', 'هل أنت متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'خروج', onPress: signOut, style: 'destructive' }
    ]);
  };

  const renderStream = ({ item }) => (
    <View style={styles.historyCard}>
      <View style={styles.historyInfo}>
        <Text style={styles.historyTitle}>{item.title}</Text>
        <Text style={styles.historyDate}>
          {item.startedAt?.toDate().toLocaleDateString('ar-SA') || 'تاريخ غير معروف'}
        </Text>
      </View>
      <View style={[styles.statusBadge, item.isLive ? styles.liveBadge : styles.endedBadge]}>
        <Text style={styles.statusText}>{item.isLive ? '● مباشر' : '✓ منتهي'}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <Image 
            source={{ uri: userData?.photoURL || 'https://via.placeholder.com/100' }} 
            style={styles.avatar} 
          />
          <View style={styles.onlineDot} />
        </View>
        <Text style={styles.name}>{userData?.displayName || 'مستخدم'}</Text>
        <Text style={styles.email}>{user?.email || 'ضيف'}</Text>

        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{userData?.followers || 0}</Text>
            <Text style={styles.statLabel}>متابعين</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{userData?.following || 0}</Text>
            <Text style={styles.statLabel}>يتابع</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <Text style={styles.statNumber}>{userData?.coins || 0}</Text>
            <Text style={styles.statLabel}>💰 رصيد</Text>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📺 سجل البثوث</Text>
        <FlatList
          data={myStreams}
          renderItem={renderStream}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <Text style={styles.emptyText}>لا يوجد بثوث سابقة</Text>
          }
        />
      </View>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleSignOut}>
        <Icon name="log-out-outline" size={20} color="#FF2D55" />
        <Text style={styles.logoutText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0f0f1e' },
  header: { alignItems: 'center', paddingTop: 60, paddingBottom: 20, backgroundColor: '#1a1a2e' },
  avatarContainer: { position: 'relative' },
  avatar: { width: 100, height: 100, borderRadius: 50, borderWidth: 3, borderColor: '#FF2D55' },
  onlineDot: { 
    position: 'absolute', bottom: 5, right: 5, width: 18, height: 18, 
    borderRadius: 9, backgroundColor: '#4CAF50', borderWidth: 3, borderColor: '#1a1a2e' 
  },
  name: { fontSize: 24, fontWeight: 'bold', color: '#fff', marginTop: 15 },
  email: { fontSize: 14, color: '#888', marginTop: 5 },
  statsRow: { flexDirection: 'row', marginTop: 20, alignItems: 'center' },
  statBox: { alignItems: 'center', paddingHorizontal: 20 },
  statNumber: { fontSize: 22, fontWeight: 'bold', color: '#FF2D55' },
  statLabel: { fontSize: 12, color: '#888', marginTop: 4 },
  statDivider: { width: 1, height: 30, backgroundColor: '#2a2a4a' },
  section: { flex: 1, padding: 20 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#fff', marginBottom: 15 },
  historyCard: { 
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#1a1a2e', padding: 15, borderRadius: 12, marginBottom: 10 
  },
  historyInfo: { flex: 1 },
  historyTitle: { color: '#fff', fontSize: 14, fontWeight: 'bold' },
  historyDate: { color: '#888', fontSize: 12, marginTop: 4 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  liveBadge: { backgroundColor: '#FF2D55' },
  endedBadge: { backgroundColor: '#2a2a4a' },
  statusText: { color: '#fff', fontSize: 11, fontWeight: 'bold' },
  emptyText: { color: '#888', textAlign: 'center', marginTop: 20 },
  logoutBtn: { 
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    marginHorizontal: 20, marginBottom: 30, paddingVertical: 14,
    borderWidth: 1, borderColor: '#FF2D55', borderRadius: 12 
  },
  logoutText: { color: '#FF2D55', marginLeft: 8, fontWeight: 'bold', fontSize: 16 }
});
