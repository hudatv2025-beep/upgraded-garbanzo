import { initializeApp } from '@react-native-firebase/app';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import storage from '@react-native-firebase/storage';
import messaging from '@react-native-firebase/messaging';

// ✅ توكنات مشروع Firebase: Modi
const firebaseConfig = {
  apiKey: "AIzaSyCMH16bddYrLgDMiQkmJLHhTSY2us9MSM",
  authDomain: "modi-717fe.firebaseapp.com",
  projectId: "modi-717fe",
  storageBucket: "modi-717fe.firebasestorage.app",
  messagingSenderId: "774056839517",
  appId: "1:774056839517:web:b192e495cd78873c8200b4",
};

if (!initializeApp.length) {
  initializeApp(firebaseConfig);
}

export { auth, firestore, storage, messaging };
export default { auth, firestore, storage, messaging };
