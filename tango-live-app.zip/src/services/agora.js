import { RtcEngine, ChannelProfile, ClientRole } from 'react-native-agora';

// ✅ Agora App ID حقيقي
const AGORA_APP_ID = "ab309994cea74610832a0531db2ba896";

class AgoraService {
  constructor() {
    this.engine = null;
  }

  async initialize() {
    this.engine = await RtcEngine.create(AGORA_APP_ID);
    await this.engine.enableVideo();
    await this.engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    return this.engine;
  }

  async joinChannel(token, channelName, uid, role = ClientRole.Audience) {
    await this.engine.setClientRole(role);
    await this.engine.joinChannel(token, channelName, null, uid);
  }

  async leaveChannel() {
    await this.engine.leaveChannel();
  }

  async switchCamera() {
    await this.engine.switchCamera();
  }

  async toggleMuteAudio(muted) {
    await this.engine.muteLocalAudioStream(muted);
  }

  async toggleMuteVideo(muted) {
    await this.engine.muteLocalVideoStream(muted);
  }

  destroy() {
    if (this.engine) {
      this.engine.destroy();
      this.engine = null;
    }
  }
}

export default new AgoraService();
